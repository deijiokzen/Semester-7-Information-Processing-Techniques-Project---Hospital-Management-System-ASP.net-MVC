﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace Hospital_Management_System
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        [WebMethod]
        public void AddDepartment(ApplicationDbContext db, Department model)
        {
            db.Department.Add(model);
            db.SaveChanges();
            return;
        }
        [WebMethod]
        public void EditDepartment(ApplicationDbContext db, Department model)
        {
            var department = db.Department.Single(c => c.Id == id);
            department.Name = model.Name;
            department.Description = model.Description;
            department.Status = model.Status;
            db.SaveChanges();
            return;
        }
        [WebMethod]
        public void DeleteDepartment(ApplicationDbContext db, Department model)
        {
            var department = db.Department.Single(c => c.Id == id);
            return;
        }
        [WebMethod]
        public void AddAmbulanceDriver(ApplicationDbContext db, Department model)
        {
            db.AmbulanceDrivers.Add(model);
            db.SaveChanges();
            return;
        }
        [WebMethod]
        public void EditAmbulanceDriver(ApplicationDbContext db, Department model)
        {
            var driver = db.AmbulanceDrivers.Single(c => c.Id == id);
            driver.Name = model.Name;
            driver.Contact = model.Contact;
            driver.Address = model.Address;
            driver.Cnic = model.Cnic;
            db.SaveChanges();
            return;
        }
        [WebMethod]
        public void AddAmbulance(ApplicationDbContext db, Department model)
        {
            var model = new AmbulanceCollection
            {
                Ambulance = new Ambulance(),
                AmbulanceDrivers = db.AmbulanceDrivers.ToList()
            };
        }
        [WebMethod]
        public void AddAmbulance(ApplicationDbContext db, Department model)
        {
            var model = new AmbulanceCollection
            {
                Ambulance = new Ambulance(),
                AmbulanceDrivers = db.AmbulanceDrivers.ToList()
            };
            db.Ambulances.Add(model.Ambulance);
            db.SaveChanges();
            return;
        }
        [WebMethod]
        public void EditAmbulance(ApplicationDbContext db, Department model)
        {
            var viewmodel = new AmbulanceCollection
            {
                Ambulance = db.Ambulances.Single(c => c.Id == id),
                AmbulanceDrivers = db.AmbulanceDrivers.ToList()
            };
            if (!ModelState.IsValid)
            {
                var viewmodel = new AmbulanceCollection
                {
                    Ambulance = model.Ambulance,
                    AmbulanceDrivers = db.AmbulanceDrivers.ToList()
                };
                return;
            }
            else
            {
                var ambulance = db.Ambulances.Single(c => c.Id == id);
                ambulance.Name = model.Ambulance.Name;
                ambulance.AmbulanceId = model.Ambulance.AmbulanceId;
                ambulance.AmbulanceStatus = model.Ambulance.AmbulanceStatus;
                ambulance.AmbulanceDriverId = model.Ambulance.AmbulanceDriverId;
            }

            db.SaveChanges();

        }
    }
}
